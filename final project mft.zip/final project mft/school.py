from tkinter import *
from tkinter import messagebox
from random import randint
import csv
filenames = ['10.csv','11.csv','12.csv']
current_file_index = None
win = Tk()
win.title('select access')
win.geometry('300x200')
win.resizable(False,False)
lb = Label(win,text='select your access please:',font=15)
lb.place(relx = 0.23,y = 20)
def rd_check():
    if rdvar.get()==0:
        btn.config(state='disabled')
    else:
        btn.config(state='normal')

def submit():
    win.withdraw()
    #----------------Student win--------------------
    if rdvar.get()==1:
        stwin = Toplevel()
        stwin.title('student')
        stwin.geometry('500x300')
        stwin.resizable(False,False)
        lbname = Label(stwin,text=' Name:',font=5)
        enname = Entry(stwin,width=12,font=3)
        lbf = Label(stwin,text=' Family:',font=5)
        enf = Entry(stwin,width=12,font=3)
        lbname.grid(row = 1,column = 3,padx = 5,pady = 5)
        enname.grid(row = 1,column = 6,padx = 5,pady = 5)
        lbf.grid(row=1, column=8, padx=5, pady=5)
        enf.grid(row=1, column=10, padx=5, pady=5)
        lbcode = Label(stwin, text=' stcode:', font=5)
        encode = Entry(stwin, width=12, font=3)
        lbcode.grid(row=2, column=3, padx=5, pady=5)
        encode.grid(row=2, column=6, padx=5, pady=5)
        grade = StringVar()
        grade.set('select')
        lbgrade = Label(stwin,text='Grade:',font=5)
        gradeop = OptionMenu(stwin,grade,'10th','11th','12th')
        gradeop.config(width=5)
        lbgrade.grid(row = 2,column = 8,padx = 5,pady = 5)
        gradeop.grid(row=2,column = 10,padx = 5,pady = 5)
        lbls = Label(stwin,text='lessons:',font=5)
        lbls.grid(row = 3,column = 1,padx = 5,pady = 5)
        c1,c2,c3 = IntVar(),IntVar(),IntVar()
        c1.set(0)
        c2.set(0)
        c3.set(0)
        chmath = Checkbutton(stwin,text='math',variable=c1,onvalue=1,offvalue=0,font=12)
        chChemistry = Checkbutton(stwin,text='Chemistry',variable=c2,onvalue=1,offvalue=0,font=12)
        chphysics  = Checkbutton(stwin,text='physics ',variable=c3,onvalue=1,offvalue=0,font=12)
        chmath.place(x = 80,y = 120)
        chChemistry.place(x = 150,y = 120)
        chphysics.place(x = 270,y = 120)
        def backst():
            stwin.withdraw()
            win.deiconify()

        def backmg():
            mgwin.withdraw()
            win.deiconify()

        def stsubmit():
            stcodes = []
            lessons = []

            for file in filenames:
                with open(file, newline='') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        stcodes.append(row['stcode'])

            if enname.get() == '' or not enname.get().isalpha():
                messagebox.showerror('error', 'just enter alphabets for your name!!')
                return
            elif enf.get() == '' or not enf.get().isalpha():
                messagebox.showerror('error', 'just enter alphabets for your last name!!')
                return
            elif not encode.get().isdigit():
                messagebox.showerror('error', 'your code must contain only numbers')
                return
            elif encode.get() in stcodes:
                messagebox.showerror('error', 'this code is already enrolled!')
                return
            elif grade.get() == 'select':
                messagebox.showerror('error', 'select your grade!!')
                return
            elif c1.get() == 0 and c2.get() == 0 and c3.get() == 0:
                messagebox.showerror('error', 'select at least one lesson!!')
                return

            if c1.get() == 1:
                lessons.append('math')
            if c2.get() == 1:
                lessons.append('chemistry')
            if c3.get() == 1:
                lessons.append('physics')

            stinfo = {
                'name': enname.get(),
                'family': enf.get(),
                'stcode': encode.get(),
                'lessons': ', '.join(lessons)
            }

            fieldnames = ['name', 'family', 'stcode', 'lessons']

            if grade.get() == '10th':
                filename = filenames[0]
            elif grade.get() == '11th':
                filename = filenames[1]
            elif grade.get() == '12th':
                filename = filenames[2]
            else:
                return

            with open(filename, 'a', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                if f.tell() == 0:
                    writer.writeheader()
                writer.writerow(stinfo)

            messagebox.showinfo('Done', 'student successfully enrolled')

        sbmt = Button(stwin,text='submit',font=13,command=stsubmit)
        bck = Button(stwin,text='Back',font=13,command=backst)
        sbmt.place(x=170,y = 240)
        bck.place(x=240,y = 240)
#----------------------manager win--------------------------
    else:
        mgwin = Toplevel()
        mgwin.title('manager')
        mgwin.geometry('400x400')
        mgwin.resizable(False,False)

        def gnrate_code():
            dcode.set(randint(1000, 9999))
        def backmg():
            mgwin.withdraw()
            win.deiconify()
        frame = Frame(mgwin)
        frame.pack(pady=20)

        listbox = Listbox(frame, width=40, height=10, font=('consolas', 11))
        listbox.pack(side=LEFT, fill=BOTH)

        scroll = Scrollbar(frame)
        scroll.pack(side=RIGHT, fill=Y)


        listbox.config(yscrollcommand=scroll.set)
        scroll.config(command=listbox.yview)




        def show_info10():
            global current_file_index
            current_file_index = 0
            listbox.delete(0, END)

            with open(filenames[0],newline='') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    listbox.insert(END, f"{row['stcode']}  {row['family']}  {row['lessons']}")

        def show_info11():
            global current_file_index
            current_file_index = 1
            listbox.delete(0, END)

            with open(filenames[1], newline='') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    listbox.insert(END, f"{row['stcode']}  {row['family']}  {row['lessons']}")

        def show_info12():
            global current_file_index
            current_file_index = 2
            listbox.delete(0, END)

            with open(filenames[2], newline='') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    listbox.insert(END, f"{row['stcode']}  {row['family']}  {row['lessons']}")
        def delete():
            selected = listbox.curselection()
            if not selected:
                messagebox.showerror('Error', 'select a row to delete!')
                return
            value = listbox.get(selected)
            print(value)
            stcode = value.split()[0]
            for file in filenames:
                with open(file, newline='') as f:
                    reader = list(csv.DictReader(f))
                for row in reader:
                    if row['stcode'] == stcode:
                        reader.remove(row)
                        with open(file, 'w', newline='') as f:
                            if len(reader) > 0:
                                writer = csv.DictWriter(f, fieldnames=reader[0].keys())
                                writer.writeheader()
                                writer.writerows(reader)
                            else:

                                fieldnames = ['name', 'family', 'stcode','lessons']
                                writer = csv.DictWriter(f, fieldnames=fieldnames)
                                writer.writeheader()
                if current_file_index==0:
                    show_info10()
                elif current_file_index==1:
                    show_info11()
                elif current_file_index==2:
                    show_info12()


        def submit_code():
            if encode.get() == "":
                messagebox.showerror('error', 'please enter code to access.')
                return

            elif not encode.get().isdigit():
                messagebox.showerror('error', 'you have to enter number in this fild!!')
                return
            elif encode.get()!= dcode.get() :
                codeerror.set('invalid code!')
                lbcodeerror.config(fg='red')
                lbcodeerror.after(2000,lambda :codeerror.set(''))
                return
            else:
                bt10.config(state='normal')
                bt11.config(state='normal')
                bt12.config(state='normal')
                btdelete.config(state='normal')

        dcode = StringVar()
        gnrate_code()
        codeerror = StringVar()
        btdelete = Button(mgwin,text='Delete',font=5,command=delete)
        btdelete.place(x = 10,y = 330)
        btdelete.config(state='disabled')
        bt10 = Button(mgwin,text='10th',font=5,command=show_info10)
        bt11 = Button(mgwin,text='11th',font=5,command=show_info11)
        bt12 = Button(mgwin,text='12th',font=5,command=show_info12)
        bt10.place(x = 80,y = 330)
        bt11.place(x = 140,y = 330)
        bt12.place(x = 200,y = 330)
        bt10.config(state='disabled')
        bt11.config(state='disabled')
        bt12.config(state='disabled')
        btback = Button(mgwin,text='back',font=5,command=backmg)
        btback.place(x = 260,y = 330)
        btgnratecode = Button(mgwin,text='Gnrate',font=5,command=gnrate_code)
        btgnratecode.place(x = 320,y = 330)
        lbt = Label(mgwin,text='enter code to access informations:',font=14)
        lbt.place(x = 70,y = 220)
        lbcodeerror =Label(mgwin,textvariable=codeerror,font=14,fg='red')
        lbcodeerror.place(x = 200 ,y = 300)
        lbcodetext = Label(mgwin,text='code:',font=14)
        lbcodetext.place(x = 70,y = 270)
        lbcode = Label(mgwin,textvariable=dcode,font=14)
        lbcode.place(x = 130,y = 270)
        encode = Entry(mgwin,width=15)
        encode.place(x = 200,y = 270)
        btsubmitcd = Button(mgwin,text='Submit',font=5,command=submit_code)
        btsubmitcd.place(x = 310, y = 270)

rdvar = IntVar()
rdvar.set(0)
rdst = Radiobutton(win,text='student',value=1,variable=rdvar,font=10,command=rd_check)
rdmanage = Radiobutton(win,text='manager',value=2,variable=rdvar,font=10,command=rd_check)
rdst.place(x = 60,y = 80)
rdmanage.place(x = 160,y = 80)
btn = Button(win,text='submit',font=10,command=submit)
btn.config(state='disabled')
btn.place(x = 120,y = 140)
mainloop()